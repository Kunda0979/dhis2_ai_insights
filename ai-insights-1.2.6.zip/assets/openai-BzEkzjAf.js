import{a as $}from"./index-D8rVyQy1.js";import{a as v,g as U}from"./App-DYQ0J1Hw.js";import"./main-BFxVv2zC.js";const D=async(t,n,a,h=[],s=null)=>{var e,r,m,o;const l=v();if(!l)throw new Error("OpenAI API key not configured");const d=U()||{},i=d.model||"gpt-4",c=d.maxTokens||2e3,u=d.temperature||.7,p=[{role:"system",content:k(n,a)}],b=h.slice(-3);p.push(...b),p.push({role:"user",content:t});try{if(s)return await I("https://api.openai.com/v1/chat/completions",{model:i,messages:p,max_tokens:c,temperature:u,n:1,stream:!0},l,s);{const g=await $.post("https://api.openai.com/v1/chat/completions",{model:i,messages:p,max_tokens:c,temperature:u,n:1},{headers:{"Content-Type":"application/json",Authorization:`Bearer ${l}`}}),f=g.data.choices[0].message.content,w=O(f);return{message:f,recommendations:w.length>0?w:null,usage:g.data.usage}}}catch(g){console.error("OpenAI API Error:",((e=g.response)==null?void 0:e.data)||g.message);const f=((o=(m=(r=g.response)==null?void 0:r.data)==null?void 0:m.error)==null?void 0:o.message)||g.message;throw f&&f.includes("maximum context length")?new Error('Too much conversation history. Please click "Clear Chat" to start fresh and try your question again.'):new Error(f||"Failed to communicate with OpenAI API. Please check your API key and try again.")}},I=async(t,n,a,h)=>{var d,i;let s="",l=null;try{const c=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${a}`},body:JSON.stringify(n)});if(!c.ok){const e=await c.json();throw new Error(((d=e.error)==null?void 0:d.message)||"Failed to communicate with OpenAI API")}const u=c.body.getReader(),y=new TextDecoder;for(;;){const{done:e,value:r}=await u.read();if(e)break;const o=y.decode(r).split(`
`);for(const g of o)if(g.startsWith("data: ")){const f=g.slice(6);if(f==="[DONE]")break;try{const w=JSON.parse(f),A=(i=w.choices[0])==null?void 0:i.delta;A!=null&&A.content&&(s+=A.content,h(A.content)),w.usage&&(l=w.usage)}catch{continue}}}const p=O(s);return{message:s,recommendations:p.length>0?p:null,usage:l}}catch(c){throw console.error("OpenAI Streaming Error:",c),(c.message||"").includes("maximum context length")?new Error('Too much conversation history. Please click "Clear Chat" to start fresh and try your question again.'):c}},N=async t=>{var n,a,h,s;try{return{success:!0,models:(await $.get("https://api.openai.com/v1/models",{headers:{Authorization:`Bearer ${t}`}})).data.data.filter(i=>i.id.includes("gpt")).map(i=>i.id)}}catch(l){throw console.error("OpenAI API Connection Test Error:",((n=l.response)==null?void 0:n.data)||l.message),new Error(((s=(h=(a=l.response)==null?void 0:a.data)==null?void 0:h.error)==null?void 0:s.message)||"Failed to connect to OpenAI API. Please check your API key and try again.")}},k=(t,n)=>{let a="";if(t&&t.headers){const h=t.headers,s=t.rows||[];if(t.hasData||s.length>0){const d=s.slice(0,5);a=`Data Sample:
`;const i=e=>t.metaData&&t.metaData.items&&t.metaData.items[e]&&t.metaData.items[e].name||e,c=e=>t.metaData&&t.metaData.items&&t.metaData.items[e]&&t.metaData.items[e].name||u(e),u=e=>{if(!e||typeof e!="string")return e;if(e.match(/^\d{6}$/)){const r=e.substring(0,4),m=parseInt(e.substring(4,6));return`${["January","February","March","April","May","June","July","August","September","October","November","December"][m-1]} ${r}`}if(e.match(/^\d{4}Q\d$/)){const r=e.substring(0,4);return`Q${e.substring(5,6)} ${r}`}return e.match(/^\d{4}$/)?`Year ${e}`:e},y=h.findIndex(e=>e.name==="dx"),p=h.findIndex(e=>e.name==="pe"),b=h.map((e,r)=>r===y&&y!==-1?"Data Element":r===p&&p!==-1?"Period":e.column).join(",");a+=b+`
`,d.forEach(e=>{const r=e.map((m,o)=>o===y&&y!==-1?i(m):o===p&&p!==-1?c(m):m).join(",");a+=r+`
`}),s.length>5&&(a+=`... (and ${s.length-5} more rows)
`),t.summary&&(a+=`
Summary Statistics:
`,Object.entries(t.summary).forEach(([e,r])=>{e!=="orgUnitBreakdown"&&(a+=`${e}: ${JSON.stringify(r)}
`)}),t.summary.orgUnitBreakdown&&(a+=`
Organization Unit Breakdown:
`,Object.entries(t.summary.orgUnitBreakdown).forEach(([e,r])=>{a+=`
${e}:
`,Object.entries(r).forEach(([m,o])=>{a+=`  ${m}: Mean=${o.mean}, Min=${o.min}, Max=${o.max}, Count=${o.count}
`})})),t.summary.periodBreakdown&&(a+=`
Period-by-Period Breakdown:
`,Object.entries(t.summary.periodBreakdown).forEach(([e,r])=>{a+=`
${e}:
`,Object.entries(r).forEach(([m,o])=>{a+=`  ${m}: Mean=${o.mean}, Min=${o.min}, Max=${o.max}, Count=${o.count}
`})})),t.summary.timeSeriesData&&(a+=`
Time Series Data (Chronological Order):
`,Object.entries(t.summary.timeSeriesData).forEach(([e,r])=>{a+=`
${e} over time:
`,r.forEach(m=>{a+=`  ${m.period}: ${m.value}
`})})))}else a=`No data available for the selected data elements in the specified period and location.

Selected data elements: `+(t.dataElements&&t.metaData&&t.metaData.items?t.dataElements.map(d=>{var i;return((i=t.metaData.items[d])==null?void 0:i.name)||"Unknown Element"}).join(", "):"Unknown")+`
Period: `+n.period+`
Organization Unit: `+(n.orgUnit.displayName||n.orgUnit.name||n.orgUnit.id)+`

Note: This is likely because:
- This is a development/test system without complete data
- The specific combination of elements, period, and location has no records
- The data elements may be new or not yet populated
`}return`
You are an AI assistant specialized in analyzing DHIS2 health data for healthcare professionals and decision-makers in resource-constrained settings. Your goal is to provide clear, actionable insights that can help save lives and improve health outcomes.

IMPORTANT: Never display technical identifiers (UIDs like "UsSUX0cpKsH") in your response. Always refer to data elements and organization units by their proper names.

## Context:
- User: ${n.user.name} (${n.user.username})
- Organization Units: ${n.user.orgUnits}
- Data Elements: ${Array.isArray(n.dataElements)?n.dataElements.join(", "):"None selected"}
- Period: ${n.period}
- Organization Unit: ${n.orgUnit.displayName||n.orgUnit.name||"Selected organization unit"}
${n.orgUnit.level?`- Organization Unit Level: ${n.orgUnit.level}`:""}
${n.orgUnit.path?`- Organization Unit Hierarchy: ${n.orgUnit.path.split("/").slice(1).join(" > ")}`:""}
${n.multiOrgUnitMode?`
- **MULTI-ORGANIZATION UNIT ANALYSIS ENABLED**
- Analysis Type: Comparative analysis across ${n.childOrgUnits.length} child organization units
- Child Organization Units: ${n.childOrgUnits.map(h=>h.displayName||h.name).join(", ")}
${n.childOrgUnits.length>0&&n.childOrgUnits[0].level?`- Child Org Unit Level: ${n.childOrgUnits[0].level}`:""}
- Focus: Individual organization unit performance comparison and ranking`:""}

## Your Task:
- Analyze the provided health data carefully and objectively
- Present clear, factual insights about trends, patterns, and anomalies
- Provide specific, actionable recommendations when appropriate
- Consider the context of low-resource settings, emergency situations, and limited time
- Format your response in a clear, readable way using markdown
- Be concise but comprehensive

## Data:
${a}

When formulating your response:
1. First analyze the data briefly to understand what it represents
2. If there is data available:
   - Provide key observations and trends in the data
   - **TIME SERIES ANALYSIS**: Look at the "Time Series Data" and "Period-by-Period Breakdown" sections to identify trends over time, seasonal patterns, peaks, and declines
   - **PERIOD COMPARISON**: When asked about which month/period has highest/lowest values, refer to the period breakdowns and time series data
   - Highlight any notable patterns, anomalies, or concerning indicators
   ${n.multiOrgUnitMode?`   - **FOR MULTI-ORG UNIT ANALYSIS**: Compare performance across organization units, identify best and worst performers, highlight disparities and outliers
   - **RANKING AND COMPARISON**: When asked, provide clear rankings and identify specific organization units that need attention
   - **GEOGRAPHIC INSIGHTS**: Consider geographic or administrative factors that might explain differences between organization units`:""}
   - Conclude with 2-5 specific, actionable recommendations
3. If there is NO data available:
   - Acknowledge the lack of data without being repetitive
   - Provide 2-3 BRIEF suggestions specific to the selected data elements about possible next steps
   - Avoid lengthy explanations about data collection in general
   - Do NOT assume problems with data collection - this is a development system and may simply not have data
4. Always use a professional, direct tone appropriate for healthcare contexts

Focus on delivering practical insights that can inform immediate decision-making in healthcare contexts, particularly in low-resource or emergency settings.

Remember:
1. Avoid showing technical details like UIDs (e.g., "UsSUX0cpKsH") in your analysis
2. If data element names aren't clear, refer to them by their position or general type (e.g., "the first disease," "disease type A")
3. Focus on the patterns and insights rather than the raw data representation
4. ALWAYS use the organization unit's display name (${n.orgUnit.displayName||n.orgUnit.name||"organization unit"}) in your responses, not the ID
`},O=t=>{const n=[],a=[/## Recommendations\s+([\s\S]+?)(?=##|$)/i,/Recommendations:\s+([\s\S]+?)(?=##|$)/i,/I recommend\s+([\s\S]+?)(?=##|$)/i,/Actions to consider:\s+([\s\S]+?)(?=##|$)/i];for(const h of a){const s=t.match(h);if(s&&s[1]){const l=s[1].trim(),d=l.match(/[•\-\*]\s+([^\n]+)/g);if(d){d.forEach(c=>{n.push(c.replace(/[•\-\*]\s+/,"").trim())});continue}const i=l.match(/\d+\.\s+([^\n]+)/g);if(i){i.forEach(c=>{n.push(c.replace(/\d+\.\s+/,"").trim())});continue}n.length===0&&l.split(`
`).filter(u=>u.trim()).forEach(u=>{n.push(u.trim())})}}return n};export{D as sendToOpenAI,N as testOpenAIConnection};
//# sourceMappingURL=openai-BzEkzjAf.js.map
