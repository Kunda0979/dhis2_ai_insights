import{g as v}from"./App-DYQ0J1Hw.js";import{a as $}from"./index-D8rVyQy1.js";import"./main-BFxVv2zC.js";$.defaults.timeout=12e4;const D=async(t,e,s={})=>{const l={...{method:"GET",data:null,timeout:12e4},...s},r=`${t.endsWith("/")?t.slice(0,-1):t}/${e}`;console.log(`Making request to: ${r}`);try{return(await $({method:l.method,url:r,data:l.method==="POST"?l.data:void 0,timeout:l.timeout,headers:{"Content-Type":"application/json",Accept:"application/json","X-Requested-With":"XMLHttpRequest"},withCredentials:!1})).data}catch(a){throw console.error("Ollama API Request Error:",a),a.code==="ERR_NETWORK"||a.message&&a.message.includes("Network Error")?window.location.hostname.includes("dhis2.org")||window.location.hostname.includes("play.im")||window.location.pathname.includes("/api/apps/")?new Error(`Cannot connect to Ollama at ${t} from DHIS2. Please use the proxy server:

1. Make sure Ollama is running on your computer
2. Navigate to the 'ollama-proxy' folder in the app directory
3. Run 'npm install' (first time only)
4. Run 'npm start' to start the proxy
5. Use http://localhost:3000 as your Ollama server URL`):new Error(`Cannot connect to Ollama at ${t}. Is Ollama running?
Check that Ollama is running on your computer and try again.`):a.response?new Error(`Ollama server at ${t} returned error ${a.response.status}: ${a.response.statusText}`):new Error(`Failed to connect to Ollama at ${t}. ${a.message}`)}},S=async(t,e)=>D(t,e,{method:"GET"}),U=async(t,e,s)=>D(t,e,{method:"POST",data:s}),T=async(t,e,s,d=[],l=null)=>{var o,h,g;const p=v()||{},r=p.ollamaServerUrl||"http://localhost:11434",a=p.ollamaModel||"llama3",m=p.maxTokens||2e3;console.log("Ollama received data:",e?{hasData:e.hasData,rowsLength:e.rows?e.rows.length:0,headersLength:e.headers?e.headers.length:0}:"No data");const u=[{role:"system",content:N(e,s)}],E=d.slice(-10);u.push(...E),u.push({role:"user",content:t});try{const n=await U(r,"api/chat",{model:a,messages:u,options:{num_predict:m}});console.log("Ollama raw response:",n.substring?n.substring(0,500)+"...":n),console.log("Response type:",typeof n);let i="";if(typeof n=="string"){console.log("Found streaming response format");try{const f=n.split(`
`).filter(y=>y.trim());if(f.length>0){const y=[];for(const O of f)try{const w=JSON.parse(O);w.message&&w.message.content&&y.push(w.message.content)}catch{console.log("Skipping invalid JSON in stream:",O.substring(0,30)+"...")}i=y.join(""),console.log("Reconstructed message from stream parts:",i.substring(0,100)+"...")}else i=n}catch(f){console.warn("Error processing streaming response:",f),i=n}}else n.message&&n.message.content?(console.log("Found message.content format"),i=n.message.content):n.content?(console.log("Found content format"),i=n.content):n.response?(console.log("Found response format"),i=n.response):n.data&&n.data.message&&n.data.message.content?(console.log("Found data.message.content format"),i=n.data.message.content):n.data&&n.data.content?(console.log("Found data.content format"),i=n.data.content):n.data&&n.data.response?(console.log("Found data.response format"),i=n.data.response):(console.warn("Could not find message in Ollama response:",n),i="Unable to extract response from Ollama. Please check the console logs for details.");const b=A(i);return{message:i,recommendations:b.length>0?b:null,model:a}}catch(n){console.error("Ollama API Error:",((o=n.response)==null?void 0:o.data)||n.message);const i=((g=(h=n.response)==null?void 0:h.data)==null?void 0:g.error)||n.message;throw new Error(`Failed to communicate with Ollama API at ${r}: ${i}`)}},C=async t=>{try{const e=await S(t,"api/tags"),s=e.models?e.models.map(d=>d.name):[];return{success:!0,models:s,message:`Successfully connected to Ollama server at ${t}. ${s.length} models available.`}}catch(e){throw console.error("Ollama API Connection Test Error:",e),new Error(`Failed to connect to Ollama at ${t}. ${e.message}`)}},N=(t,e)=>{let s="";if(console.log("Creating system prompt with data:",t?{hasHeaders:!!t.headers,hasRows:!!(t.rows&&t.rows.length),hasDataFlag:!!t.hasData,rowCount:t.rows?t.rows.length:0,headerCount:t.headers?t.headers.length:0,hasMetaData:!!(t.metaData&&t.metaData.items),hasDataElements:!!(t.dataElements&&t.dataElements.length)}:"No data"),console.log("Context received:",{period:e.period,orgUnit:e.orgUnit?{id:e.orgUnit.id,displayName:e.orgUnit.displayName,name:e.orgUnit.name}:"No org unit",dataElements:e.dataElements?Array.isArray(e.dataElements)?e.dataElements.length:"Not an array":"No data elements",user:e.user?e.user.name:"No user"}),t&&t.headers){const d=t.headers,l=t.rows||[];if(t.hasData||l.length>0){const r=l.slice(0,10);s=`Data Sample:
`;const a=o=>t.metaData&&t.metaData.items&&t.metaData.items[o]&&t.metaData.items[o].name||o,m=d.findIndex(o=>o.name==="dx"),c=d.findIndex(o=>o.name==="ou"),u=d.findIndex(o=>o.name==="pe"),E=d.map((o,h)=>h===m&&m!==-1?"Data Element":h===c&&c!==-1?"Organization Unit":h===u&&u!==-1?"Period":o.column).join(",");s+=E+`
`,r.forEach(o=>{const h=o.map((g,n)=>n===m&&m!==-1||n===c&&c!==-1||n===u&&u!==-1?a(g):g).join(",");s+=h+`
`}),l.length>10&&(s+=`... (and ${l.length-10} more rows)
`),t.summary&&(s+=`
Summary Statistics:
`,Object.entries(t.summary).forEach(([o,h])=>{s+=`${o}: ${h}
`}))}else{s=`No data available for the selected data elements in the specified period and location.

`;let r="Unknown";t.dataElements&&Array.isArray(t.dataElements)?t.metaData&&t.metaData.items?r=t.dataElements.map(a=>{var m,c;return typeof a=="string"?((m=t.metaData.items[a])==null?void 0:m.name)||a:a&&a.id?((c=t.metaData.items[a.id])==null?void 0:c.name)||a.id:"Unknown Element"}).join(", "):r=t.dataElements.map(a=>typeof a=="string"?a:a&&a.id?a.id:"Unknown").join(", "):e.dataElements&&Array.isArray(e.dataElements)&&(r=e.dataElements.join(", ")),s+="Selected data elements: "+r+`
Period: `+e.period+`
Organization Unit: `+(e.orgUnit.displayName||e.orgUnit.name||e.orgUnit.id)+`

Note: This is likely because:
- This is a development/test system without complete data
- The specific combination of elements, period, and location has no records
- The data elements may be new or not yet populated
`}}else s=`No data structure is available to analyze. The system might be experiencing issues retrieving data.
You can try selecting different data elements, a different time period, or a different organization unit.
`;return`
You are an AI assistant specialized in analyzing DHIS2 health data for healthcare professionals and decision-makers in resource-constrained settings. Your goal is to provide clear, actionable insights that can help save lives and improve health outcomes.

IMPORTANT: Never display technical identifiers (UIDs like "UsSUX0cpKsH") in your response. Always refer to data elements and organization units by their proper names.

## Context:
- User: ${e.user.name} (${e.user.username})
- Organization Units: ${e.user.orgUnits}
- Data Elements: ${Array.isArray(e.dataElements)?e.dataElements.join(", "):"None selected"}
- Period: ${e.period}
- Organization Unit: ${e.orgUnit.displayName||e.orgUnit.name||"Selected organization unit"}

## Your Task:
- Analyze the provided health data carefully and objectively
- Present clear, factual insights about trends, patterns, and anomalies
- Provide specific, actionable recommendations when appropriate
- Consider the context of low-resource settings, emergency situations, and limited time
- Format your response in a clear, readable way using markdown
- Be concise but comprehensive

## Data:
${s}

When formulating your response:
1. First analyze the data briefly to understand what it represents
2. If there is data available:
   - Provide key observations and trends in the data
   - Highlight any notable patterns, anomalies, or concerning indicators
   - Conclude with 2-5 specific, actionable recommendations
3. If there is NO data available:
   - Acknowledge the lack of data without being repetitive
   - Provide 2-3 BRIEF suggestions specific to the selected data elements about possible next steps
   - Avoid lengthy explanations about data collection in general
   - Do NOT assume problems with data collection - this is a development system and may simply not have data
4. Always use a professional, direct tone appropriate for healthcare contexts

Focus on delivering practical insights that can inform immediate decision-making in healthcare contexts, particularly in low-resource or emergency settings.

Remember:
1. Avoid showing technical details like UIDs (e.g., "UsSUX0cpKsH") in your analysis
2. If data element names aren't clear, refer to them by their position or general type (e.g., "the first disease," "disease type A")
3. Focus on the patterns and insights rather than the raw data representation
4. ALWAYS use the organization unit's display name (${e.orgUnit.displayName||e.orgUnit.name||"organization unit"}) in your responses, not the ID
`},A=t=>{const e=[],s=[/## Recommendations\s+([\s\S]+?)(?=##|$)/i,/Recommendations:\s+([\s\S]+?)(?=##|$)/i,/I recommend\s+([\s\S]+?)(?=##|$)/i,/Actions to consider:\s+([\s\S]+?)(?=##|$)/i];for(const d of s){const l=t.match(d);if(l&&l[1]){const p=l[1].trim(),r=p.match(/[•\-\*]\s+([^\n]+)/g);if(r){r.forEach(m=>{e.push(m.replace(/[•\-\*]\s+/,"").trim())});continue}const a=p.match(/\d+\.\s+([^\n]+)/g);if(a){a.forEach(m=>{e.push(m.replace(/\d+\.\s+/,"").trim())});continue}e.length===0&&p.split(`
`).filter(c=>c.trim()).forEach(c=>{e.push(c.trim())})}}return e};export{T as sendToOllama,C as testOllamaConnection};
//# sourceMappingURL=ollama-BMou_FJF.js.map
